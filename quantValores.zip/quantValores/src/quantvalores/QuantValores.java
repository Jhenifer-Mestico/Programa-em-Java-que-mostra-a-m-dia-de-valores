/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quantvalores;

/**
 *
 * @author Jhenifer
 */
import javax.swing.*;
public class QuantValores {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
          int  i, quant;
        double  valores, soma;
        
        quant = Integer.parseInt(JOptionPane.showInputDialog(null, 
                "Digite a quantidade de valores desejado:",
                "Valor(es) desejados", JOptionPane.INFORMATION_MESSAGE));
        soma = 0;
        
        for(i=1; i<=quant; i++){
            valores = Double.parseDouble(JOptionPane.showInputDialog(null, 
                "Por favor, digite um valor:",
                "Valor(es)", JOptionPane.INFORMATION_MESSAGE));
            soma =  soma + valores;
        }
        JOptionPane.showMessageDialog(null, "A média dos valores será: " + soma / quant, "Resultado",
                JOptionPane.INFORMATION_MESSAGE);
    
        
    }
    
}
